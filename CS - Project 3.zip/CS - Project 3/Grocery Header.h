#pragma once
#include <iostream>
#include <string>
#include <map>

using namespace std;

//Declaring our class
class grocery {
public:
	string userInput;
	void groceryMap();
private:
	//setting up our map for our grocery items
	void groceryMap() {
		std::map<std::string, int> groceryList;

		groceryList["Spinach"] = 5;
		groceryList["Radishes"] = 3;
		groceryList["Broccoli"] = 7;
		groceryList["Peas"] = 8;
		groceryList["Cranberries"] = 10;
		groceryList["Potatoes"] = 5;
		groceryList["Cucumbers"] = 9;
		groceryList["Peaches"] = 5;
		groceryList["Zucchini"] = 10;
		groceryList["Cantaloupe"] = 2;
		groceryList["Beets"] = 3;
		groceryList["Cauliflower"] = 5;
		groceryList["Onion"] = 4;
		groceryList["Yams"] = 5;
		groceryList["Apples"] = 5;
		groceryList["Celery"] = 6;
		groceryList["Limes"] = 1;
		groceryList["Garlic"] = 8;
		groceryList["Pumpkin"] = 2;
		groceryList["Pears"] = 1;

		//Beginning of our output for the user and the function to print the desired item
		cout << "Enter a grocery item or type exit." << endl;
		string searchItem;
		getline(cin, searchItem);

		if (item == "exit") {
			break;
		}

		auto it = groceryList.find(searchItem);

		if (it != groceryList.end()) {
			cout << "Item: " << it->first << ", Quantity: " << it->second << endl;
			cout << "Item: " << it->first << ", Quantity: ";
			for (int i = 0; i < it->second; ++i) {
				cout << "*";
			}
			cout << endl;

		}
		else {
			cout << "Item not found please try again or type exit to end the program." << endl;

		}
		return 0;
	}


};

